package com.javaguides.javaio.ioexamples;

public class FileUtility {
	public static void getFileSize(){
		
	}
}
