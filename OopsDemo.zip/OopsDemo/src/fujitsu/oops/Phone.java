package fujitsu.oops;

public class Phone {
//Declaration of state/Properties.
	String brand;//Instance variable
	String color;//Instance variable
	String os;
	double width;
	double height;
	double price;
// Declaration of constructor.	
	Phone(String b,double p){
		brand=b;
		price=p;
	}
	// Declaration of Actions. 
    void aboutPhone(double width,double height) // Instance method. 
    {

    System.out.println("Brand :"+brand);
    System.out.println("Price :"+price);
    System.out.println("width :"+width+"cm");
    System.out.println("Height :"+height+"cm");
    System.out.println("color :"+color);
    System.out.println("OS :"+os);
    
    }
 // Declaration of instance block. 
    { 
    	System.out.println("Mobile Specification");
    } 
   
public static void main(String[] args) 
 { 
   //Object Creation
	Phone p=new Phone("Apple",48000);
	p.color="black";
	p.os="iOS";
	p.aboutPhone(5.86, 12.3);
	
  }
}
